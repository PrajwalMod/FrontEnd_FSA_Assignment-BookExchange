import React from 'react';
import { Link } from 'react-router-dom';
import '../styles/Homepage.css';
function Homepage() {
  return (
    <div className="container">
      <h1>Welcome to the Book Exchange Platform</h1>
      <p>Reading with a sustainable approach!</p>
      <p>Select an option below</p>
        <li className="button"><Link to="/login">Login</Link></li>
        <li className="button"><Link to="/register">Register</Link></li>
    </div>
  );
}

export default Homepage;
